//
//  MapViewController.swift
//  APIDemo
//
//  Created by MacStudent on 2019-07-02.
//  Copyright © 2019 Parrot. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Alamofire
import SwiftyJSON

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate{
  
   
    @IBOutlet weak var map: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        map.delegate = self
        
        let URL = "https://mad4114example1.firebaseio.com/.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
         
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
      
            // 2a. Convert the response to a JSON object
            let jsonResponse = JSON(apiData)
           // for loop to show games location on map
            for i in 0...3{
                            var  lat = (jsonResponse["fifa"][i][0]["Lat"].double)
                            var  long = (jsonResponse["fifa"][i][0]["Long"].double)
                            print(lat!)
                            let pin = MKPointAnnotation()
                            let coord = CLLocationCoordinate2DMake(lat!, long!)
                            pin.coordinate = coord
                            pin.title = ""
                            self.map.addAnnotation(pin)
            }
//            var  lat = (jsonResponse["fifa"][3][0]["Lat"].double)
//            var  long = (jsonResponse["fifa"][3][0]["Long"].double)
//            print(lat!)
//            let pin = MKPointAnnotation()
//            let coord = CLLocationCoordinate2DMake(lat!, long!)
//            pin.coordinate = coord
//            pin.title = ""
//            self.map.addAnnotation(pin)
//            //2
//            var  latSemi = (jsonResponse["fifa"][0][0]["Lat"].double)
//            var  longSemi = (jsonResponse["fifa"][0][0]["Long"].double)
//            let pin2 = MKPointAnnotation()
//            let coord2 = CLLocationCoordinate2DMake(latSemi!, longSemi!)
//            pin2.coordinate = coord2
//            pin2.title = ""
//            self.map.addAnnotation(pin2)
//            //3
//            var  latFinal = (jsonResponse["fifa"][1][0]["Lat"].double)
//            var  longFinal = (jsonResponse["fifa"][1][0]["Long"].double)
//            let pin3 = MKPointAnnotation()
//            let coord3 = CLLocationCoordinate2DMake(latFinal!, longFinal!)
//            pin3.coordinate = coord3
//            pin3.title = ""
//            self.map.addAnnotation(pin3)
//            //2
//            var  latquater = (jsonResponse["fifa"][2][0]["Lat"].double)
//            var  longquater = (jsonResponse["fifa"][2][0]["Long"].double)
//            let pin4 = MKPointAnnotation()
//            let coord4 = CLLocationCoordinate2DMake(latquater!, longquater!)
//            pin4.coordinate = coord4
//            pin4.title = ""
//            self.map.addAnnotation(pin4)
            
        }

        
    

        // Do any additional setup after loading the view.
        
        // set the center of the map
        


    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        
        print(view.annotation?.title!)
        
        let vc1 = self.storyboard?.instantiateViewController(withIdentifier: "viewController")
        self.navigationController?.pushViewController(vc1!, animated: true)
        
    }

}
