//
//  DetailViewController.swift
//  APIDemo
//
//  Created by MacStudent on 2019-07-02.
//  Copyright © 2019 Parrot. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class DetailViewController: UIViewController {
    
    var receiveData = Int()

    @IBAction func btnUnsubscribe(_ sender: Any) {
        
    }
    @IBOutlet weak var LabelTeamA: UILabel!
    @IBOutlet weak var LabelTeamB: UILabel!
    @IBOutlet weak var LabelLocation: UILabel!
    @IBOutlet weak var LabelTime: UILabel!
    @IBOutlet weak var LabelDate: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Received data on detail screen is \(receiveData)")
        // Do any additional setup after loading the view.
        
        let URL = "https://mad4114example1.firebaseio.com/.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            
            
            // 2a. Convert the response to a JSON object
            let jsonResponse = JSON(apiData)
             print(jsonResponse["fifa"][self.receiveData])
            self.LabelTeamA.text = jsonResponse["fifa"][self.receiveData][0]["TeamA"].string!
            self.LabelTeamB.text = jsonResponse["fifa"][self.receiveData][0]["TeamB"].string!
            self.LabelLocation.text = jsonResponse["fifa"][self.receiveData][0]["Place"].string!
            self.LabelTime.text = jsonResponse["fifa"][self.receiveData][0]["Time"].string!
            self.LabelDate.text = jsonResponse["fifa"][self.receiveData][0]["Date"].string!

            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
