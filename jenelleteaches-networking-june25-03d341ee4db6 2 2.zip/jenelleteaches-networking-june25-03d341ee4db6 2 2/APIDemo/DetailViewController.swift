//
//  DetailViewController.swift
//  APIDemo
//
//  Created by MacStudent on 2019-07-02.
//  Copyright © 2019 Parrot. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import WatchConnectivity

class DetailViewController: UIViewController, WCSessionDelegate {
    
    @IBOutlet weak var lblSub: UILabel!
    
    @IBOutlet weak var btnYes: UIButton!
    
    var receiveData = Int()
    var isBtnPressed = 0

    
    @IBOutlet weak var LabelTeamA: UILabel!
    @IBOutlet weak var LabelTeamB: UILabel!
    @IBOutlet weak var LabelLocation: UILabel!
    @IBOutlet weak var LabelTime: UILabel!
    @IBOutlet weak var LabelDate: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Received data on detail screen is \(receiveData)")
        // Do any additional setup after loading the view.
        
        let URL = "https://mad4114example1.firebaseio.com/.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            
            
            // 2a. Convert the response to a JSON object
            let jsonResponse = JSON(apiData)
             print(jsonResponse["fifa"][self.receiveData])
            self.LabelTeamA.text = "Team A: \(jsonResponse["fifa"][self.receiveData][0]["TeamA"].string!)"
            self.LabelTeamB.text = "Team B: \(jsonResponse["fifa"][self.receiveData][0]["TeamB"].string!)"
            self.LabelLocation.text = "Place: \(jsonResponse["fifa"][self.receiveData][0]["Place"].string!)"
            self.LabelTime.text = "Time: \(jsonResponse["fifa"][self.receiveData][0]["Time"].string!)"
            self.LabelDate.text = "Date: \(jsonResponse["fifa"][self.receiveData][0]["Date"].string!)"

            
        }
        if (WCSession.isSupported()) {
            print("PHONE: Phone supports WatchConnectivity!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("PHONE: Phone does not support WatchConnectivity")
        }
        
    }
    
    
   
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        
    }
    
    @IBAction func btnYes(_ sender: Any) {
        if (lblSub.text == "Subscribe"){
            if (WCSession.default.isReachable) {
                
                
                let abc = ["index": receiveData]
                // send the message to the watch
                WCSession.default.sendMessage(abc, replyHandler: nil)
                
            }
            else {
                print("PHONE: Cannot find the watch")
            }
            lblSub.text = "Unsubscribe"
           
        }
        
        else if lblSub.text == "Unsubscribe" {

            if (WCSession.default.isReachable) {


                let abc = ["index": receiveData]
                // send the message to the watch
                WCSession.default.sendMessage(abc, replyHandler: nil)

            }
            else {
                print("PHONE: Cannot find the watch")
            }
            lblSub.text = "Subscribe"

        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
