//
//  data.swift
//  APIDemo
//
//  Created by MacStudent on 2019-07-02.
//  Copyright © 2019 Parrot. All rights reserved.
//

import Foundation


class data: Codable {
    var TeamA : String
    init(TeamA: String) {
        self.TeamA = TeamA
    }
}
