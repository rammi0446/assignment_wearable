//
//  ViewController.swift
//  APIDemo
//
//  Created by Parrot on 2019-03-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import WatchConnectivity

class ViewController: UIViewController, WCSessionDelegate, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var tableViewToShowData: UITableView!
    var jsonGlobal : JSON! = nil
    var arr = [data]()
    
  
   
    
    // MARK: Default functions
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        tableViewToShowData.delegate = self
        tableViewToShowData.dataSource = self
        
        let URL = "https://mad4114example1.firebaseio.com/Fifa.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
          
            
            // 2a. Convert the response to a JSON object
            let jsonResponse = JSON(apiData)
      
            print(jsonResponse)
            
           var a = jsonResponse["third"].dictionary
            self.arr.append(a)
         
            // 2b. Get the array out of the JSON object
         
//            print("\(jsonResponse["third"]["7"]["TeamA"])")
            
            self.jsonGlobal = jsonResponse
            
        }
    
    
        // Does your iPhone support "talking to a watch"?
        // If yes, then create the session
        // If no, then output error message
        if (WCSession.isSupported()) {
            print("PHONE: Phone supports WatchConnectivity!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("PHONE: Phone does not support WatchConnectivity")
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewToShowData.dequeueReusableCell(withIdentifier: "myRow", for: indexPath) as! TableViewCell
        cell.labelName.text = "test"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//            let vc1 = self.storyboard?.instantiateViewController(withIdentifier: "detail")
//            self.navigationController?.pushViewController(vc1!, animated: true)
        
      
        
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        
    }

    
    // MARK: Actions
    
    @IBAction func buttonPressed(_ sender: Any) {
        print("button pressed")
        
        // check if the watch is paired / accessible
        if (WCSession.default.isReachable) {
            // construct the message you want to send
            // the message is in dictionary
            let abc = [
                "lastName":"albert",
                "firstName":"danison",
                "email":"a@gmail.com",
                "lat":"50.0",
                "lng":"97.0",
                "username":"adanison",
                "password":"0000"
            ]
            // send the message to the watch
            WCSession.default.sendMessage(abc, replyHandler: nil)
        }
        else {
            print("PHONE: Cannot find the watch")
        }
        
    }
    
    
}

