//
//  ViewController.swift
//  APIDemo
//
//  Created by Parrot on 2019-03-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import WatchConnectivity

class ViewController: UIViewController, WCSessionDelegate, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var tableViewToShowData: UITableView!

    var arr = [String]()
    var subscribedGame:String!
    var detailSendToNextVC = Int()
    var JsonPass: JSON!
   
    
    // MARK: Default functions
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        tableViewToShowData.delegate = self
        tableViewToShowData.dataSource = self
        
        let URL = "https://mad4114example1.firebaseio.com/.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
          
            
            // 2a. Convert the response to a JSON object
            let jsonResponse = JSON(apiData)
            self.JsonPass = jsonResponse
            for i in 0...3{
                print(jsonResponse["fifa"][i][0]["TeamA"])
                self.arr.append(jsonResponse["fifa"][i][0]["TeamA"].string!)
                self.tableViewToShowData.reloadData()
            }

        }
    
    
        // Does your iPhone support "talking to a watch"?
        // If yes, then create the session
        // If no, then output error message
        if (WCSession.isSupported()) {
            print("PHONE: Phone supports WatchConnectivity!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("PHONE: Phone does not support WatchConnectivity")
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewToShowData.dequeueReusableCell(withIdentifier: "myRow", for: indexPath) as! TableViewCell
        cell.labelName.text = arr[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
  
        let indexPath = tableView.indexPathForSelectedRow!
        let currentCell = tableView.cellForRow(at: indexPath)! as! TableViewCell
        
       // detailSendToNextVC = currentCell.labelName.text!
        detailSendToNextVC = indexPath.row
        performSegue(withIdentifier: "mySegue", sender: self)
        print(indexPath.row)
        subscribedGame = String(indexPath.row)
        print("subscribed Game : \(subscribedGame)")
       
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        if (segue.identifier == "mySegue") {
            // initialize new view controller and cast it as your view controller
            let viewController = segue.destination as? DetailViewController
            // your new view controller should have property that will store passed value
            viewController?.receiveData = detailSendToNextVC
        }

    }

    
    // MARK: Actions
    
    @IBAction func buttonPressed(_ sender: Any) {
        print("button pressed")
        
        // check if the watch is paired / accessible
        if (WCSession.default.isReachable) {
            // construct the message you want to send
            // the message is in dictionary
//            let abc = [
//                "lastName":"albert",
//                "firstName":"danison",
//                "email":"a@gmail.com",
//                "lat":"50.0",
//                "lng":"97.0",
//                "username":"adanison",
//                "password":"0000"
//            ]
            // send the message to the watch
           WCSession.default.sendMessage(self.subscribedGame, replyHandler: nil)
        }
        else {
            print("PHONE: Cannot find the watch")
        }
        
    }
    
    
}

