//
//  InterfaceController.swift
//  APIDemo WatchKit Extension
//
//  Created by Parrot on 2019-03-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit
import Foundation
import Alamofire
import SwiftyJSON
import WatchConnectivity

class InterfaceController: WKInterfaceController, WCSessionDelegate {
    
    var arr = [String]()
    var arrTeamB = [String]()
    var arrImagesA = [String]()
    var arrImagesB = [String]()
    var subscribedGame = Int()
    var unSubscribedGame = Int()
    var arrSubscribedTeamA = [String]()
    var arrSubscribedTeamB = [String]()
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    
    // MARK: Outlet
    // ---------------
 
    @IBOutlet var watchOutputLabel: WKInterfaceLabel!
    
    
    // MARK: Actions
    @IBAction func getDataPressed() {
        print("Watch button pressed")
        // TODO: Put your API call here
        let URL = "https://mad4114example1.firebaseio.com/.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            
            
            // 2a. Convert the response to a JSON object
            let jsonResponse = JSON(apiData)
            print("Game Subscribed for  \(jsonResponse["fifa"][self.subscribedGame][0]["TeamA"]) vs \(jsonResponse["fifa"][self.subscribedGame][0]["TeamB"]) match")
            print("Game UnSubscribed for  \(jsonResponse["fifa"][self.unSubscribedGame][0]["TeamA"]) vs \(jsonResponse["fifa"][self.unSubscribedGame][0]["TeamB"]) match")
            //array for subscribed unsubscribed games
//            self.arrSubscribedTeamA.append(jsonResponse["fifa"][self.subscribedGame][0]["TeamA"].string!)
//            self.arrSubscribedTeamB.append(jsonResponse["fifa"][self.subscribedGame][0]["TeamB"].string!)
            
            for i in 0...3{
               // print(jsonResponse["fifa"][i][0]["TeamA"])
                self.arr.append(jsonResponse["fifa"][i][0]["TeamA"].string!)
                self.arr.append(jsonResponse["fifa"][i][0]["TeamB"].string!)
            }
        }
    }
    
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        if (WCSession.isSupported()) {
            print("Watch: Phone supports WatchConnectivity!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("Watch: Phone does not support WatchConnectivity")
        }
        
    }
   
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        print("WATCH: Got a message! on first screen")
        
        
        subscribedGame = message["index"] as! Int
        
       
    }
    
    

}
