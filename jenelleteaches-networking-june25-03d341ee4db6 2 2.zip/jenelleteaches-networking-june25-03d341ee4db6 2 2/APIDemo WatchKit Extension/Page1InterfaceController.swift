//
//  Page1InterfaceController.swift
//  APIDemo WatchKit Extension
//
//  Created by MacStudent on 2019-06-26.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity
import Alamofire
import SwiftyJSON

class Page1InterfaceController: WKInterfaceController, WCSessionDelegate {
    
    
   
    // MARK: Outlets
    // ----------
    //outlet for the table
    @IBOutlet var tableViewThing: WKInterfaceTable!
    
    // outlet for label to hold messages from phone
    @IBOutlet var phoneMessageLabel: WKInterfaceLabel!
    
    // MARK: Data source
   var arr = [String]()
    var arrTeamB = [String]()
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        
        print("WATCH: Got a message!")
        print(message)
        
        // update the message with a label
        self.phoneMessageLabel.setText("\(message)")
    }
    
    
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        // API
        let URL = "https://mad4114example1.firebaseio.com/.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            
            
            // 2a. Convert the response to a JSON object
            let jsonResponse = JSON(apiData)
            
            for i in 0...3{
                print(jsonResponse["fifa"][i][0]["TeamA"])
                self.arr.append(jsonResponse["fifa"][i][0]["TeamA"].string!)
                self.arrTeamB.append(jsonResponse["fifa"][i][0]["TeamB"].string!)
            }
            
            // 1. Tell watch how many rows you want
            self.tableViewThing.setNumberOfRows(
                self.arr.count, withRowType:"myRow"
            )
            
            // 2. Tell watch what data goes in each row
            for (index, data) in self.arr.enumerated() {
                let row = self.tableViewThing.rowController(at: index) as! RowController
                row.outputLabel.setText(data)
                row.outputLabelB.setText(self.arrTeamB[index])
                row.imageTeamA.setImage(UIImage(named: data))
                row.imageTeamB.setImage(UIImage(named: self.arrTeamB[index]))
            }
            
            
        }
        
        
        
        // check for wcsession
        if (WCSession.isSupported()) {
            print("WATCH: WCSession is supported!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("WATCH: Does not support WCSession, sorry!")
        }
        

        
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
