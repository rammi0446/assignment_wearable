//
//  SubscribedRowController.swift
//  APIDemo WatchKit Extension
//
//  Created by MacStudent on 2019-07-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit

class SubscribedRowController: NSObject {

    @IBOutlet var labelSubscribedGames: WKInterfaceLabel!
    
}
