//
//  SubscribedInterfaceController.swift
//  APIDemo WatchKit Extension
//
//  Created by MacStudent on 2019-07-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity
import Alamofire
import SwiftyJSON

class SubscribedInterfaceController: WKInterfaceController, WCSessionDelegate {
    
    @IBOutlet var subscribedTableView: WKInterfaceTable!
    
    let arr : [String] = ["Sagar", "raman", "Deep"]
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        
        // check for wcsession
        if (WCSession.isSupported()) {
            print("WATCH: WCSession is supported!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        else {
            print("WATCH: Does not support WCSession, sorry!")
        }
        
        // 1. Tell watch how many rows you want
        self.subscribedTableView.setNumberOfRows(
            self.arr.count, withRowType:"myRow2"
        )

        // 2. Tell watch what data goes in each row
        for (index, data) in self.arr.enumerated() {
            let row = self.subscribedTableView.rowController(at: index) as! SubscribedRowController
            row.labelSubscribedGames.setText(data)
        }
        
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        
        print("WATCH: Got a message! on second screen")
        print(message)
        
    }

}
